package servicio_json;
import java.math.BigDecimal;

import com.google.gson.*;

public class ParamEliminarArticulo {
    int id;
}
