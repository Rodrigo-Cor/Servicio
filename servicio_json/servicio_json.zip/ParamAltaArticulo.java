package servicio_json;

public class ParamAltaArticulo {
    Articulo articulo;
}