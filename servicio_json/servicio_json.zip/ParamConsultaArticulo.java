package servicio_json;
import com.google.gson.*;

public class ParamConsultaArticulo {
    String busqueda;
}
