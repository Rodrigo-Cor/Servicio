package servicio_json;
import java.math.BigDecimal;

public class ArticuloCarrito {
    byte[] foto;
    int id;
    String nombre;
    BigDecimal precio;
    int cantidad;
}
