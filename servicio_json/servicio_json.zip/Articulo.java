package servicio_json;

import java.math.BigDecimal;

public class Articulo {
    int id;
    String nombre;
    String descripcion;
    BigDecimal precio;
    int cantidad;
    byte[] foto;
}
