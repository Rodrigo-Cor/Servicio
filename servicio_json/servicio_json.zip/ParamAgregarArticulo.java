package servicio_json;
import com.google.gson.*;

public class ParamAgregarArticulo {
    int id;
    int cantidad;    
}
